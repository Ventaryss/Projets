# Prometheus + Node Exporter + Grafana Monitoring Setup (Ansible)

## Structure

- `install_prometheus.yml` — Playbook to install and configure the Prometheus monitoring server
- `install_node_exporter.yml` — Playbook to deploy the node_exporter agent on all target machines
- `install_grafana.yml` — Playbook to install Grafana, link it to Prometheus and import dashboards
- `roles/`
  - `prometheus_server/` — Role to install and configure Prometheus server
  - `node_exporter/` — Role to install and configure Node Exporter agent
  - `grafana/`
    - `tasks/`
      - `main.yml` — Installs Grafana and configures datasource
      - `import_dashboards.yml` — Copies and provisions dashboards
    - `files/`
      - `node_exporter_full.json` — Basic system dashboard
      - `network_traffic.json` — Dashboard for per-interface traffic
    - `templates/`
      - `prometheus_datasource.yml.j2` — Links Grafana to Prometheus

## Instructions

1. Prepare your inventory file (`inventory.ini`) and group your Prometheus host under `[prometheus]`.

2. Run the playbooks:
```bash
ansible-playbook -i inventory.ini install_prometheus.yml
ansible-playbook -i inventory.ini install_node_exporter.yml
ansible-playbook -i inventory.ini install_grafana.yml
```

3. Access dashboards:
- Prometheus: `http://<prometheus_server_ip>:9090`
- Grafana: `http://<prometheus_server_ip>:3000` (Login: admin / admin)

4. Dashboards auto-imported:
- Node Exporter Full
- Network Traffic per Interface