# Prometheus + Node Exporter Monitoring Setup (Ansible)

## Structure

- `install_prometheus.yml` — Playbook to install and configure the Prometheus monitoring server
- `install_node_exporter.yml` — Playbook to deploy the node_exporter agent on all target machines
- `roles/`
  - `prometheus_server/` — Role to install and configure Prometheus server
  - `node_exporter/` — Role to install and configure Node Exporter agent

## Instructions

1. Adjust your inventory:
   - Group your Prometheus host under `[prometheus]`
   - List all others as clients

2. Run the playbooks:
```bash
ansible-playbook -i inventory.ini install_prometheus.yml
ansible-playbook -i inventory.ini install_node_exporter.yml
```

3. Open your browser to:
```
http://<prometheus_server_ip>:9090
```

Metrics from each node (via port 9100) should appear after a few seconds.