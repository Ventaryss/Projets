# Prometheus + Node Exporter + Grafana Monitoring Setup (Ansible)

## Structure

- `install_prometheus.yml` — Playbook to install and configure the Prometheus monitoring server
- `install_node_exporter.yml` — Playbook to deploy the node_exporter agent on all target machines
- `install_grafana.yml` — Playbook to install Grafana and link it to Prometheus
- `roles/`
  - `prometheus_server/` — Role to install and configure Prometheus server
  - `node_exporter/` — Role to install and configure Node Exporter agent
  - `grafana/` — Role to install and configure Grafana with Prometheus as data source

## Instructions

1. Adjust your inventory:
   - Group your Prometheus host under `[prometheus]`
   - List all others as clients

2. Run the playbooks:
```bash
ansible-playbook -i inventory.ini install_prometheus.yml
ansible-playbook -i inventory.ini install_node_exporter.yml
ansible-playbook -i inventory.ini install_grafana.yml
```

3. Access dashboards:

- Prometheus metrics:  
  `http://<prometheus_server_ip>:9090`

- Grafana dashboards:  
  `http://<prometheus_server_ip>:3000`  
  Login: `admin` / Password: `admin` (by default)